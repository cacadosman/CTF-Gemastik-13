package com.cacadosman.pesugihanonline.service.impl;

import com.cacadosman.pesugihanonline.model.Role;
import com.cacadosman.pesugihanonline.model.User;
import com.cacadosman.pesugihanonline.repository.RoleRepository;
import com.cacadosman.pesugihanonline.repository.UserRepository;
import com.cacadosman.pesugihanonline.service.UserService;
import com.cacadosman.pesugihanonline.utils.ROLE;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserRepository userRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    BCryptPasswordEncoder encoder;

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        Optional<User> user = userRepository.findByUsername(s);
        if (!user.isPresent())
            throw new UsernameNotFoundException("User not found");
        return user.get();
    }

    @Override
    public User getUserFromSession() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return null;
        } else if (auth.getPrincipal() instanceof User) {
            return (User) auth.getPrincipal();
        }
        return null;
    }

    @Override
    public void register(User user) {
        Optional<User> hasUserOpt = userRepository.findByUsername(user.getUsername());
        if (hasUserOpt.isPresent()) {
            throw new RuntimeException("Username sudah terdaftar");
        }

        user.setPassword(encoder.encode(user.getPassword()));
        userRepository.save(user);
    }
}
