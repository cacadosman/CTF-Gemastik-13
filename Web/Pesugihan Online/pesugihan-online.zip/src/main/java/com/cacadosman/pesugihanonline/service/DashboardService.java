package com.cacadosman.pesugihanonline.service;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

public interface DashboardService {
    String dashboard(Model model);
}
