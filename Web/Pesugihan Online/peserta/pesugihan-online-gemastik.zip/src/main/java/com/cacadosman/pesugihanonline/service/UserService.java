package com.cacadosman.pesugihanonline.service;

import com.cacadosman.pesugihanonline.model.User;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    User getUserFromSession();
    void register(User user);
}
