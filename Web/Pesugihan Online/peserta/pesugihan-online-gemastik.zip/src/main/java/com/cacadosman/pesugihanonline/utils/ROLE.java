package com.cacadosman.pesugihanonline.utils;

public class ROLE {
    public static String User = "ROLE_USER";
    public static String Admin = "ROLE_ADMIN";
}
