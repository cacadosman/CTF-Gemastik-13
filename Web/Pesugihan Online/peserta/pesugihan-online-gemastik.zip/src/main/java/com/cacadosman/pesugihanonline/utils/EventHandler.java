package com.cacadosman.pesugihanonline.utils;

import com.cacadosman.pesugihanonline.model.Role;
import com.cacadosman.pesugihanonline.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class EventHandler {
    @Autowired
    RoleRepository roleRepository;

    @EventListener
    public void seedDatabase(ContextRefreshedEvent event) {
        Role roleAdmin = Role.builder()
                .id(UUID.randomUUID())
                .name(ROLE.Admin)
                .build();
        Role roleUser = Role.builder()
                .id(UUID.randomUUID())
                .name(ROLE.User)
                .build();
        roleRepository.save(roleAdmin);
        roleRepository.save(roleUser);
    }
}
