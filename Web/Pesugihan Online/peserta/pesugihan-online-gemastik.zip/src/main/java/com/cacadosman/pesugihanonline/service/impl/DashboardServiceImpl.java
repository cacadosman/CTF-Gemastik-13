package com.cacadosman.pesugihanonline.service.impl;

import com.cacadosman.pesugihanonline.model.User;
import com.cacadosman.pesugihanonline.service.DashboardService;
import com.cacadosman.pesugihanonline.service.UserService;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import java.util.Collection;

@Service
public class DashboardServiceImpl implements DashboardService {
    @Autowired
    UserService userService;

    @Override
    public String dashboard(Model model) {
        User user = userService.getUserFromSession();
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext()
                .getAuthentication().getAuthorities();
        String authority = StringEscapeUtils.escapeHtml3(authorities.iterator().next().getAuthority());
        model.addAttribute("username", StringEscapeUtils.escapeHtml3(user.getUsername()));
        return "app :: " + authority;
    }
}
