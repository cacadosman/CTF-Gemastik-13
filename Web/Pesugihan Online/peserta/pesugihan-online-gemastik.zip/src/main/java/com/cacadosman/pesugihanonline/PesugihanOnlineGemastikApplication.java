package com.cacadosman.pesugihanonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PesugihanOnlineGemastikApplication {

    public static void main(String[] args) {
        SpringApplication.run(PesugihanOnlineGemastikApplication.class, args);
    }

}
