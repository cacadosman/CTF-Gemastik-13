package com.cacadosman.pesugihanonline.service;

import org.springframework.ui.Model;

public interface DashboardService {
    String dashboard(Model model);
}
