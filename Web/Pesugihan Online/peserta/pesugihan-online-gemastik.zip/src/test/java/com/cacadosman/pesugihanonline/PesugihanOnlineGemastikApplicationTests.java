package com.cacadosman.pesugihanonline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PesugihanOnlineGemastikApplicationTests {

    @Test
    void contextLoads() {
    }

}
